<?php 
namespace Magento\Modalpopup\Controller\Index;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Encryption\EncryptorInterface as Encryptor;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\ResultFactory; 
use Magento\Framework\Intl\DateTimeFactory;
use Magento\Customer\Model\ResourceModel\Visitor\CollectionFactory;
use Magento\Framework\Stdlib\DateTime;
use Magento\Framework\Session\SaveHandlerInterface;

class Save extends \Magento\Framework\App\Action\Action
{
	protected $resultPageFactory;
 
	public function __construct(
	   \Magento\Framework\App\Action\Context $context,
	   \Magento\Customer\Api\AccountManagementInterface $AccountManagementInterface,
	   \Magento\Customer\Model\AccountManagement $AccountManagement,
	   CustomerRepositoryInterface $customerRepository,
	   \Magento\Customer\Model\CustomerRegistry $customerRegistry,
	   SessionManagerInterface $sessionManager = null,
	   Encryptor $encryptor,
	   \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
	   Session $customerSession,
	   AccountRedirect $accountRedirect,
	   ScopeConfigInterface $scopeConfig,
	   DateTimeFactory $dateTimeFactory = null,
	   CollectionFactory $visitorCollectionFactory = null,
	   \Magento\Framework\Controller\ResultFactory $ResultFactory,
	   \Magento\Framework\ObjectManagerInterface $objectManager,
	   SaveHandlerInterface $saveHandler = null,
	   \Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		$this->session = $customerSession;
		$this->AccountManagementInterface = $AccountManagementInterface;
		$this->resultPageFactory = $resultPageFactory;
		$this->customerRepository = $customerRepository;
		$this->AccountManagement = $AccountManagement;
		$this->customerRegistry = $customerRegistry;
		$this->encryptor = $encryptor;
		$this->sessionManager = $sessionManager
            ?: ObjectManager::getInstance()->get(SessionManagerInterface::class);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->accountRedirect = $accountRedirect;
        $this->scopeConfig = $scopeConfig;
		$this->resultFactory = $ResultFactory;
		$this->_objectManager = $objectManager;
		$this->dateTimeFactory = $dateTimeFactory ?: ObjectManager::getInstance()->get(DateTimeFactory::class);
		$this->saveHandler = $saveHandler
            ?: ObjectManager::getInstance()->get(SaveHandlerInterface::class);
		 $this->visitorCollectionFactory = $visitorCollectionFactory
            ?: ObjectManager::getInstance()->get(CollectionFactory::class);
		parent::__construct($context);
	}

	public function execute()
	{
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$redirectUrl = $this->session->getBeforeAuthUrl();
		$postData = $this->getRequest()->getPostValue();
		$customer = $this->customerRepository->get($postData["username"]);
		if($customer){
			$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
			$customerSecure = $this->customerRegistry->retrieveSecureData($customer->getId());
	        $customerSecure->setRpToken(null);
	        $customerSecure->setRpTokenCreatedAt(null);
	        $customerSecure->setPasswordHash($this->createPasswordHash($postData["password"]));
	        $this->sessionManager->destroy();
	       	$this->destroyCustomerSessions($customer->getId());
	        $this->customerRepository->save($customer);
	        $this->messageManager->addSuccess(__('Thanks for registration.'));
            $this->session->setCustomerDataAsLoggedIn($customer);
            $this->session->regenerateId();
			$result= ['result' =>'success','url'=>$this->_url->getUrl('customer/account')];
		}
		$this->getResponse()->representJson(
            $this->_objectManager->get(\Magento\Framework\Json\Helper\Data::class)->jsonEncode($result)
        );
	}
	protected function createPasswordHash($password)
    {
        return $this->encryptor->getHash($password, true);
    }
    private function destroyCustomerSessions($customerId)
    {
        $sessionLifetime = $this->scopeConfig->getValue(
            \Magento\Framework\Session\Config::XML_PATH_COOKIE_LIFETIME,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $dateTime = $this->dateTimeFactory->create();
        $activeSessionsTime = $dateTime->setTimestamp($dateTime->getTimestamp() - $sessionLifetime)
            ->format(DateTime::DATETIME_PHP_FORMAT);
        /** @var \Magento\Customer\Model\ResourceModel\Visitor\Collection $visitorCollection */
        $visitorCollection = $this->visitorCollectionFactory->create();
        $visitorCollection->addFieldToFilter('customer_id', $customerId);
        $visitorCollection->addFieldToFilter('last_visit_at', ['from' => $activeSessionsTime]);
        $visitorCollection->addFieldToFilter('session_id', ['neq' => $this->sessionManager->getSessionId()]);
        /** @var \Magento\Customer\Model\Visitor $visitor */
        foreach ($visitorCollection->getItems() as $visitor) {
            $sessionId = $visitor->getSessionId();
            $this->sessionManager->start();
            $this->saveHandler->destroy($sessionId);
            $this->sessionManager->writeClose();
        }
	}
}